<?php

require_once "../config/database.php";

class Utilisateur {

public static function login($email, $password) {

    $pdo = getConnection();

    $email = trim(strtolower($email));

    $sql = $pdo->prepare("
        SELECT *
        FROM utilisateur
        WHERE LOWER(TRIM(email)) = ?
    ");

    $sql->execute([$email]);

    $user = $sql->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        return false;
    }

    if (trim($user['motDePasse']) !== trim($password)) {
        return false;
    }

    return $user;
}

    public static function emailExists($email) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            SELECT COUNT(*) 
            FROM utilisateur
            WHERE email = ?
        ");

        $sql->execute([$email]);

        return $sql->fetchColumn() > 0;
    }

    public static function register(
        $nom,
        $email,
        $password,
        $role,
        $nomEntreprise = null
    ) {

        $pdo = getConnection();

        $role = strtolower(trim($role));

    

        if (
            !in_array(
                $role,
                ['etudiant', 'entreprise', 'responsable']
            )
        ) {

            return [false, "Rôle invalide"];
        }


        if (self::emailExists($email)) {

            return [false, "Email déjà utilisé"];
        }


        $sql = $pdo->prepare("
            INSERT INTO utilisateur
            (
                nom,
                email,
                motDePasse,
                role
            )

            VALUES
            (
                ?,
                ?,
                ?,
                ?
            )
        ");

        $ok = $sql->execute([
            $nom,
            $email,
            $password,
            $role
        ]);

        if (!$ok) {

            return [false, "Erreur insertion utilisateur"];
        }

        $idUser = $pdo->lastInsertId();

        if ($role === 'etudiant') {

            $sql2 = $pdo->prepare("
                INSERT INTO etudiant
                (
                    idUtilisateur
                )

                VALUES
                (
                    ?
                )
            ");

            $sql2->execute([$idUser]);
        }

        elseif ($role === 'entreprise') {

            $nomEnt = $nomEntreprise ?: $nom;

            $sql3 = $pdo->prepare("
                INSERT INTO entreprise
                (
                    idUtilisateur,
                    nomEntreprise
                )

                VALUES
                (
                    ?,
                    ?
                )
            ");

            $sql3->execute([
                $idUser,
                $nomEnt
            ]);
        }

        elseif ($role === 'responsable') {

            $sql4 = $pdo->prepare("
                INSERT INTO responsable
                (
                    idUtilisateur
                )

                VALUES
                (
                    ?
                )
            ");

            $sql4->execute([$idUser]);
        }


        $getUser = $pdo->prepare("
            SELECT *
            FROM utilisateur
            WHERE idUtilisateur = ?
        ");

        $getUser->execute([$idUser]);

        $user = $getUser->fetch(PDO::FETCH_ASSOC);

        return [true, $user];
    }
}
?>