<?php

require_once "../config/database.php";

class OffreStage {


    public static function getAll() {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            SELECT
                o.*,
                e.nomEntreprise
            FROM offrestage o

            LEFT JOIN entreprise e
            ON o.idEntreprise = e.idUtilisateur

            ORDER BY o.idOffre DESC
        ");

        $sql->execute();

        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }


    public static function getByEntreprise($idEntreprise) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            SELECT *
            FROM offrestage
            WHERE idEntreprise = ?
            ORDER BY idOffre DESC
        ");

        $sql->execute([$idEntreprise]);

        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function getValidated() {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            SELECT
                o.*,
                e.nomEntreprise
            FROM offrestage o

            LEFT JOIN entreprise e
            ON o.idEntreprise = e.idUtilisateur

            WHERE o.statut = 'validee'

            ORDER BY o.idOffre DESC
        ");

        $sql->execute();

        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }


    public static function getById($id) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            SELECT *
            FROM offrestage
            WHERE idOffre = ?
        ");

        $sql->execute([$id]);

        return $sql->fetch(PDO::FETCH_ASSOC);
    }


    public static function add(
        $titre,
        $description,
        $competences,
        $typeContrat,
        $idEntreprise
    ) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            INSERT INTO offrestage
            (
                titre,
                description,
                competences,
                typeContrat,
                datePublication,
                idEntreprise,
                statut
            )

            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                NOW(),
                ?,
                'en_attente'
            )
        ");

        $sql->execute([
            $titre,
            $description,
            $competences,
            $typeContrat,
            $idEntreprise
        ]);
    }


    public static function update(
        $id,
        $titre,
        $description,
        $competences,
        $typeContrat
    ) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            UPDATE offrestage

            SET
                titre = ?,
                description = ?,
                competences = ?,
                typeContrat = ?

            WHERE idOffre = ?
        ");

        $sql->execute([
            $titre,
            $description,
            $competences,
            $typeContrat,
            $id
        ]);
    }


    public static function delete($id) {

        $pdo = getConnection();

        /* DELETE CANDIDATURES */

        $sql1 = $pdo->prepare("
            DELETE FROM candidature
            WHERE idOffre = ?
        ");

        $sql1->execute([$id]);

        /* DELETE OFFRE */

        $sql2 = $pdo->prepare("
            DELETE FROM offrestage
            WHERE idOffre = ?
        ");

        $sql2->execute([$id]);
    }


    public static function valider($id, $idResponsable) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            UPDATE offrestage

            SET
                statut = 'validee',
                idResponsable = ?

            WHERE idOffre = ?
        ");

        $sql->execute([
            $idResponsable,
            $id
        ]);
    }


    public static function refuser($id, $idResponsable) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            UPDATE offrestage

            SET
                statut = 'refusee',
                idResponsable = ?

            WHERE idOffre = ?
        ");

        $sql->execute([
            $idResponsable,
            $id
        ]);
    }


    public static function search($keyword) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            SELECT
                o.*,
                e.nomEntreprise

            FROM offrestage o

            LEFT JOIN entreprise e
            ON o.idEntreprise = e.idUtilisateur

            WHERE o.titre LIKE ?

            ORDER BY o.idOffre DESC
        ");

        $search = "%$keyword%";

        $sql->execute([$search]);

        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>