<?php

require_once "../config/database.php";

class Candidature {


    public static function postuler($idOffre, $idEtudiant) {

        $pdo = getConnection();

        /* CHECK DEJA POSTULE */

        $check = $pdo->prepare("
            SELECT COUNT(*) 
            FROM candidature
            WHERE idEtudiant = ?
            AND idOffre = ?
        ");

        $check->execute([
            $idEtudiant,
            $idOffre
        ]);

        $nb = $check->fetchColumn();

        if ($nb > 0) {
            return;
        }

        /* INSERT */

        $sql = $pdo->prepare("
            INSERT INTO candidature
            (
                idEtudiant,
                idOffre,
                dateCandidature,
                statut
            )
            VALUES
            (
                ?,
                ?,
                NOW(),
                'en_attente'
            )
        ");

        $sql->execute([
            $idEtudiant,
            $idOffre
        ]);
    }



    public static function getByEtudiant($id) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            SELECT
                c.*,
                o.titre
            FROM candidature c
            JOIN offrestage o
            ON c.idOffre = o.idOffre
            WHERE c.idEtudiant = ?
            ORDER BY c.idCandidature DESC
        ");

        $sql->execute([$id]);

        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }



    public static function getByEntreprise($idEntreprise) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            SELECT
                c.*,
                o.titre,
                u.nom
            FROM candidature c

            JOIN offrestage o
            ON c.idOffre = o.idOffre

            JOIN utilisateur u
            ON c.idEtudiant = u.idUtilisateur

            WHERE o.idEntreprise = ?

            ORDER BY c.idCandidature DESC
        ");

        $sql->execute([$idEntreprise]);

        return $sql->fetchAll(PDO::FETCH_ASSOC);
    }

    

    public static function accepter($id) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            UPDATE candidature
            SET statut = 'acceptee'
            WHERE idCandidature = ?
        ");

        $sql->execute([$id]);
    }


    public static function refuser($id) {

        $pdo = getConnection();

        $sql = $pdo->prepare("
            UPDATE candidature
            SET statut = 'refusee'
            WHERE idCandidature = ?
        ");

        $sql->execute([$id]);
    }
}
?>