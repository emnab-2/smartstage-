<?php
$nom = $_SESSION['user']['nom']; 
$firstLetter = strtoupper(substr($nom, 0, 1));

$currentPage = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
?>

<style>
.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: linear-gradient(180deg,#8e2de2,#4a00e0);
    padding: 20px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    color: white;
}

.logo {
    font-size: 22px;
    font-weight: bold;
    margin-bottom: 30px;
}

.menu a {
    display: block;
    padding: 12px;
    border-radius: 12px;
    color: white;
    text-decoration: none;
    margin-bottom: 10px;
    transition: 0.3s;
    font-size: 14px;
}

.menu a:hover {
    background: rgba(255,255,255,0.2);
}

.menu .active {
    background: white;
    color: #4a00e0;
    font-weight: 600;
}

.profile {
    background: rgba(255,255,255,0.1);
    padding: 12px;
    border-radius: 15px;
}

.user-box {
    display: flex;
    align-items: center;
    gap: 10px;
}

.avatar {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    background: white;
    color: #4a00e0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.logout-btn {
    margin-top: 10px;
    background: #ef4444;
    color: white;
    padding: 10px;
    border-radius: 10px;
    text-align: center;
    display: block;
    text-decoration: none;
    font-size: 13px;
}

.logout-btn:hover {
    background: #dc2626;
}
</style>

<div class="sidebar">

    <div>

        <div class="logo">SmartStage 🚀</div>

        <div class="menu">

            <a href="dashboard_etudiant.php"
               class="<?= strpos($currentPage, 'dashboard_etudiant') !== false ? 'active' : '' ?>">
               🏠 Dashboard
            </a>

            <a href="offres_etudiant.php"
               class="<?= strpos($currentPage, 'offres_etudiant') !== false ? 'active' : '' ?>">
               🔍 Offres
            </a>

            <a href="mes_candidatures.php"
               class="<?= strpos($currentPage, 'mes_candidatures') !== false ? 'active' : '' ?>">
               📄 Mes Candidatures
            </a>

        </div>

    </div> 


    <div class="profile">
        <div class="user-box">
            <div class="avatar"><?= $firstLetter ?></div>
            <div>
                <strong><?= $nom ?></strong><br>
                <small>Étudiant</small>
            </div>
        </div>

        <a href="logout.php" class="logout-btn">🔒 Logout</a>
    </div>

</div>