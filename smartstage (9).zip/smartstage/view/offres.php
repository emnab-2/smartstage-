<?php
require_once "../config/auth.php";
checkAuth();

require_once "../model/OffreStage.php";

$offres = OffreStage::getAll();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Offres</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background:#0f172a;
    color:white;
    padding:30px;
}
</style>
</head>

<body>

<h2>Liste des Offres 📊</h2>

<form method="GET" action="../controller/OffreController.php">
    <input type="text" name="search" placeholder="Rechercher..."
           value="<?= $_GET['search'] ?? '' ?>">
    <button type="submit">🔍</button>
</form>

<br>

<table class="table table-dark">

<tr>
<th>ID</th>
<th>Titre</th>
<th>Description</th>
<th>Statut</th>
<th>Actions</th>
</tr>

<?php foreach ($offres as $offre): ?>

<tr>

<td><?= $offre['idOffre'] ?></td>

<td><?= htmlspecialchars($offre['titre']) ?></td>

<td><?= htmlspecialchars($offre['description']) ?></td>

<td><?= $offre['statut'] ?></td>

<td>
<a href="../controller/OffreController.php?edit=<?= $offre['idOffre'] ?>">✏</a>
<a href="../controller/OffreController.php?delete=<?= $offre['idOffre'] ?>">❌</a>
</td>

</tr>

<?php endforeach; ?>

</table>

<br>

<a href="dashboard_entreprise.php">⬅ Retour</a>

</body>
</html>