<?php
require_once "../config/auth.php";
checkRole('entreprise');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter Offre</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { margin: 0; font-family: 'Poppins', sans-serif; }
        .main {
            margin-left: 250px;
            padding: 34px 40px;
            min-height: 100vh;
            background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
            color: white;
        }
        .form-card {
            max-width: 760px;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(148,163,184,0.3);
            border-radius: 18px;
            padding: 22px;
        }
        .form-control {
            background: rgba(15,23,42,0.8);
            border: 1px solid rgba(148,163,184,0.45);
            color: #f8fafc;
        }
        .form-control:focus {
            background: #020617;
            color: #f8fafc;
            border-color: #8b5cf6;
            box-shadow: none;
        }
        .btn-purple {
            background: linear-gradient(45deg,#8e2de2,#4a00e0);
            color: white;
            border: none;
        }
    </style>
</head>
<body>
<?php require_once "sidebar_entreprise.php"; ?>
<main class="main">
    <h2 class="mb-3">Ajouter une offre ➕</h2>
    <div class="form-card">
        <form method="POST" action="../controller/OffreController.php">
            <div class="mb-3">
                <label class="form-label">Titre</label>
                <input type="text" name="titre" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="4" required></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Compétences</label>
                <input type="text" name="competences" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Type de contrat</label>
                <input type="text" name="typeContrat" class="form-control" placeholder="Stage / CDI / CDD..." required>
            </div>

            <button type="submit" name="add" class="btn btn-purple">Publier l'offre</button>
        </form>
    </div>
</main>
</body>
</html>