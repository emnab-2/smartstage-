<?php
require_once "../config/auth.php";
checkRole('etudiant');

require_once "../model/OffreStage.php";

$offres = OffreStage::getValidated();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Offres Étudiant</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    margin:0;
    font-family:'Poppins', sans-serif;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color:white;
}

.main {
    margin-left:250px;
    padding:40px;
}

.offer-card {
    background: rgba(255,255,255,0.05);
    border-radius:15px;
    padding:20px;
    margin-bottom:20px;
    display:flex;
    justify-content:space-between;
}
</style>
</head>

<body>

<?php require_once "sidebar_etudiant.php"; ?>

<div class="main">

<input type="text" id="search" class="form-control mb-4" placeholder="🔍 Rechercher...">

<h2>Offres disponibles</h2>

<div id="offres-container">

<?php foreach ($offres as $o): ?>

<div class="offer-card">

<div>
    <h5><?= $o['titre'] ?></h5>
    <small><?= $o['nomEntreprise'] ?? 'Entreprise' ?></small><br>
    <small><?= $o['datePublication'] ?></small>
</div>

<div>
<a href="../controller/CandidatureController.php?postuler=<?= $o['idOffre'] ?>"
   class="btn btn-primary btn-sm">
   Postuler
</a>
</div>

</div>

<?php endforeach; ?>

</div>

</div>

<script>
const searchInput = document.getElementById("search");

searchInput.addEventListener("keyup", function() {

let query = this.value;

fetch("../controller/SearchController.php?q=" + query)
.then(res => res.json())
.then(data => {

let container = document.getElementById("offres-container");
container.innerHTML = "";

if (data.length === 0) {
    container.innerHTML = "Aucun résultat";
    return;
}

data.forEach(o => {

container.innerHTML += `
<div class="offer-card">

<div>
    <h5>${o.titre}</h5>
    <small>${o.nomEntreprise ?? "Entreprise"}</small><br>
    <small>${o.datePublication}</small>
</div>

<div>
<a href="../controller/CandidatureController.php?postuler=${o.idOffre}">
Postuler
</a>
</div>

</div>
`;

});

});
});
</script>

</body>
</html>