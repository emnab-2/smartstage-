<?php
require_once "../config/auth.php";
checkRole('entreprise');

require_once "../model/OffreStage.php";
require_once "../model/Candidature.php";

$user = $_SESSION['user'];


$offres = OffreStage::getByEntreprise($user['idUtilisateur']);
$candidatures = Candidature::getByEntreprise($user['idUtilisateur']);

$enAttente = 0;
$acceptees = 0;

foreach ($candidatures as $c) {
    if ($c['statut'] == 'en_attente') $enAttente++;
    if ($c['statut'] == 'acceptee') $acceptees++;
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard Entreprise</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    margin:0;
    font-family:'Poppins', sans-serif;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color:white;
}

.main {
    margin-left:250px;
    padding:40px;
}

.kpis {
    display:grid;
    grid-template-columns: repeat(3,1fr);
    gap:20px;
    margin-top:30px;
}

.kpi {
    background: rgba(255,255,255,0.05);
    padding:20px;
    border-radius:15px;
    text-align:center;
}

.card-box {
    background: rgba(255,255,255,0.05);
    padding:20px;
    border-radius:15px;
    margin-top:20px;
}

.btn-purple {
    background: linear-gradient(45deg,#8e2de2,#4a00e0);
    border:none;
    color:white;
}
</style>
</head>

<body>

<?php require_once "sidebar_entreprise.php"; ?>

<div class="main">

<h1>Bienvenue <?= htmlspecialchars($user['nom']) ?> 🏢</h1>
<p>Gestion rapide de votre activité</p>

<!-- KPIs -->
<div class="kpis">
    <div class="kpi">
        <h3><?= count($offres) ?></h3>
        <small>Offres</small>
    </div>

    <div class="kpi">
        <h3><?= count($candidatures) ?></h3>
        <small>Candidatures</small>
    </div>

    <div class="kpi">
        <h3><?= $acceptees ?></h3>
        <small>Acceptées</small>
    </div>
</div>

<br>

<a href="add_offre.php" class="btn btn-purple">➕ Ajouter Offre</a>

<!-- Performance -->
<div class="card-box">
    <h5>📈 Performance</h5>

    <div class="progress mt-2" style="height:10px;">
        <div class="progress-bar bg-success"
             style="width: <?= count($candidatures) > 0 ? ($acceptees / count($candidatures)) * 100 : 0 ?>%">
        </div>
    </div>

    <small><?= $acceptees ?> acceptées / <?= count($candidatures) ?></small>
</div>

</div>

</body>
</html>