<?php
require_once "../config/auth.php";
checkRole('etudiant');

require_once "../model/Candidature.php";

$user = $_SESSION['user'];

$candidatures = Candidature::getByEtudiant($user['idUtilisateur']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Mes Candidatures</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { margin: 0; font-family: 'Poppins', sans-serif; }

.main {
    margin-left: 250px;
    padding: 34px 40px;
    min-height: 100vh;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color: white;
}

.table-box {
    background: rgba(255,255,255,0.08);
    border-radius: 16px;
    overflow: hidden;
}

.table { color: white; }

.chip {
    border-radius: 999px;
    padding: 4px 10px;
    font-size: 12px;
}

.chip-ok { background: green; }
.chip-ko { background: red; }
.chip-pending { background: orange; }
</style>

</head>

<body>

<?php require_once "sidebar_etudiant.php"; ?>

<div class="main">

<h2>Mes Candidatures 🎓</h2>

<?php if (empty($candidatures)): ?>

<p>Aucune candidature</p>

<?php else: ?>

<table class="table table-hover">

<tr>
    <th>Offre</th>
    <th>Date</th>
    <th>Statut</th>
</tr>

<?php foreach ($candidatures as $c): ?>

<tr>

<td><?= htmlspecialchars($c['titre']) ?></td>

<td><?= htmlspecialchars($c['dateCandidature']) ?></td>

<td>
<?php
$class = 'chip-pending';
if ($c['statut'] === 'acceptee') $class = 'chip-ok';
if ($c['statut'] === 'refusee') $class = 'chip-ko';
?>
<span class="<?= $class ?>">
<?= htmlspecialchars($c['statut']) ?>
</span>
</td>

</tr>

<?php endforeach; ?>

</table>

<?php endif; ?>

</div>

</body>
</html>