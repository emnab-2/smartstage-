<?php
require_once "../config/auth.php";
checkRole('entreprise');

require_once "../model/OffreStage.php";

$user = $_SESSION['user'];

$offres = OffreStage::getByEntreprise($user['idUtilisateur']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Mes Offres</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { margin: 0; font-family: 'Poppins', sans-serif; }

.main {
    margin-left: 250px;
    padding: 34px 40px;
    min-height: 100vh;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color: white;
}

.table-box {
    background: rgba(255,255,255,0.08);
    border-radius: 16px;
}

.btn-purple {
    background: linear-gradient(45deg,#8e2de2,#4a00e0);
    color: white;
}
</style>

</head>

<body>

<?php require_once "sidebar_entreprise.php"; ?>

<div class="main">

<h2>Mes Offres 💼</h2>

<a href="add_offre.php" class="btn btn-purple mb-3">
+ Ajouter une offre
</a>

<table class="table table-hover text-white">

<tr>
<th>ID</th>
<th>Titre</th>
<th>Description</th>
<th>Compétences</th>
<th>Type</th>
<th>Date</th>
<th>Statut</th>
<th>Actions</th>
</tr>

<?php foreach ($offres as $offre): ?>

<tr>

<td><?= $offre['idOffre'] ?></td>

<td><?= htmlspecialchars($offre['titre']) ?></td>

<td><?= htmlspecialchars($offre['description']) ?></td>

<td><?= htmlspecialchars($offre['competences']) ?></td>

<td><?= htmlspecialchars($offre['typeContrat']) ?></td>

<td><?= htmlspecialchars($offre['datePublication']) ?></td>

<td><?= htmlspecialchars($offre['statut']) ?></td>

<td>
<a href="../controller/OffreController.php?edit=<?= $offre['idOffre'] ?>">✏️</a>
<a href="../controller/OffreController.php?delete=<?= $offre['idOffre'] ?>">❌</a>
</td>

</tr>

<?php endforeach; ?>

</table>

</div>

</body>
</html>