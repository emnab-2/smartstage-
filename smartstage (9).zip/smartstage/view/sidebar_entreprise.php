<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$nom = $_SESSION['user']['nom'] ?? 'Entreprise';

$firstLetter = strtoupper(substr($nom, 0, 1));

$currentPage = basename(
    parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)
);
?>
<style>
.sidebar {
    width:250px;
    height:100vh;
    position:fixed;
    top:0;
    left:0;
    background: linear-gradient(180deg,#8e2de2,#4a00e0);
    padding:20px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    color:white;
}

.profile {
    background: rgba(255,255,255,0.1);
    padding:15px;
    border-radius:15px;
}

.user-box {
    display:flex;
    align-items:center;
    gap:12px;
    margin-bottom:10px; /* FIX */
}

.logout-btn {
    margin-top:15px; /* FIX */
    background:#ef4444;
    color:white;
    padding:10px;
    border-radius:10px;
    text-align:center;
    display:block;
    text-decoration:none;
}
.logo {
    font-size: 22px;
    font-weight: bold;
    margin-bottom: 30px;
}

.menu a {
    display: block;
    padding: 12px;
    border-radius: 12px;
    color: white;
    text-decoration: none;
    margin-bottom: 10px;
    transition: 0.3s;
}

.menu a:hover {
    background: rgba(255,255,255,0.2);
}

.menu .active {
    background: white;
    color: #4a00e0;
    font-weight: bold;
}

.profile {
    background: rgba(255,255,255,0.1);
    padding: 12px;
    border-radius: 15px;
}

.avatar {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    background: white;
    color: #4a00e0;
    display:flex;
    align-items:center;
    justify-content:center;
}

</style>

<div class="sidebar">
<div>
    <div class="logo">SmartStage 🚀</div>

    <div class="menu">
        <a href="dashboard_entreprise.php"
           class="<?= strpos($currentPage,'dashboard_entreprise')!==false?'active':'' ?>">
           🏠 Dashboard
        </a>

        <a href="offres_entreprise.php"
           class="<?= strpos($currentPage,'offres_entreprise')!==false?'active':'' ?>">
           💼 Mes Offres
        </a>

        <a href="candidatures.php"
           class="<?= strpos($currentPage,'candidatures')!==false?'active':'' ?>">
           📄 Candidatures
        </a>
    </div>
</div>

<div class="profile">
    <div style="display:flex;gap:10px;align-items:center;">
        <div class="avatar"><?= $firstLetter ?></div>
        <div>
            <strong><?= $nom ?></strong><br>
            <small>Entreprise</small>
        </div>
    </div>

    <a href="logout.php" class="logout-btn">🔒 Logout</a>
</div>
</div>