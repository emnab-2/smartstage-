<?php
require_once "../config/auth.php";
checkRole('entreprise');

require_once "../model/Candidature.php";

$user = $_SESSION['user'];

$candidatures = Candidature::getByEntreprise($user['idUtilisateur']); 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Candidatures</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { margin: 0; font-family: 'Poppins', sans-serif; }
.main {
    margin-left: 250px;
    padding: 34px 40px;
    min-height: 100vh;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color: white;
}
.table-box {
    background: rgba(255,255,255,0.08);
    border-radius: 16px;
    overflow: hidden;
}
.table th {
    background: rgba(139,92,246,0.55);
}
.chip { padding: 4px 10px; border-radius: 20px; font-size: 12px; }
.chip-ok { background: green; }
.chip-ko { background: red; }
.chip-pending { background: orange; }
</style>
</head>

<body>

<?php require_once "sidebar_entreprise.php"; ?>

<div class="main">

<h2>Candidatures reçues 📄</h2>

<?php if (empty($candidatures)): ?>
    <p>Aucune candidature</p>
<?php else: ?>

<table class="table table-hover">

<tr>
    <th>Offre</th>
    <th>Date</th>
    <th>Statut</th>
    <th>Actions</th>
</tr>

<?php foreach ($candidatures as $c): ?>

<tr>
    <td><?= $c['titre'] ?></td>

    <td><?= $c['dateCandidature'] ?></td>

    <td>
        <?php
            $class = 'chip-pending';
            if ($c['statut'] === 'acceptee') $class = 'chip-ok';
            if ($c['statut'] === 'refusee') $class = 'chip-ko';
        ?>
        <span class="<?= $class ?>">
            <?= $c['statut'] ?>
        </span>
    </td>

    <td>
        <?php if ($c['statut'] == 'en_attente'): ?>

            <a href="../controller/CandidatureController.php?accepter=<?= $c['idCandidature'] ?>">✔</a>

            <a href="../controller/CandidatureController.php?refuser=<?= $c['idCandidature'] ?>">❌</a>

        <?php else: ?>
            ✔ Traité
        <?php endif; ?>
    </td>

</tr>

<?php endforeach; ?>

</table>

<?php endif; ?>

</div>

</body>
</html>