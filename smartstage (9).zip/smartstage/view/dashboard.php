<?php

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <meta charset="UTF-8">
    <title>Dashboard</title>
</head>
<body>

<h2>Bienvenue 🎉</h2>

<p>
Email: <?php echo $_SESSION['user']['EMAIL']; ?>
</p>
<a href="../controller/OffreController.php">Voir les offres</a>
<a href="add_offre.php">➕ Ajouter une offre</a>
<a href="logout.php">Logout</a>

</body>
</html>