<?php
require_once "../config/auth.php";
checkRole('responsable');

require_once "../model/OffreStage.php";

$offres = OffreStage::getAll();
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Offres</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { margin:0; font-family:'Poppins', sans-serif; }

.main {
    margin-left:250px;
    padding:40px;
    min-height:100vh;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color:white;
}

.table {
    background: rgba(255,255,255,0.05);
    border-radius:15px;
}

.table th {
    background:#8e2de2;
}
</style>

</head>

<body>

<?php require_once "sidebar_responsable.php"; ?>

<div class="main">

<h2>Validation des Offres</h2>

<table class="table text-center mt-4">

<tr>
<th>Entreprise</th>
<th>Titre</th>
<th>Description</th>
<th>Statut</th>
<th>Action</th>
</tr>

<?php foreach ($offres as $o): ?>

<tr>

<td><?= $o['nomEntreprise'] ?? '-' ?></td>

<td><?= htmlspecialchars($o['titre']) ?></td>

<td><?= htmlspecialchars($o['description']) ?></td>

<td>
<?php
$class = "warning";
$text = "En attente";

if ($o['statut'] == 'validee') {
    $class = "success";
    $text = "✔ Validée";
}
elseif ($o['statut'] == 'refusee') {
    $class = "danger";
    $text = "❌ Refusée";
}
?>
<span class="badge bg-<?= $class ?>">
<?= $text ?>
</span>
</td>

<td>
<?php if ($o['statut'] == 'en_attente'): ?>

<a href="../controller/OffreController.php?valider=<?= $o['idOffre'] ?>" class="btn btn-success btn-sm">✔</a>

<a href="../controller/OffreController.php?refuser=<?= $o['idOffre'] ?>" class="btn btn-danger btn-sm">❌</a>

<?php else: ?>
✔ Traité
<?php endif; ?>
</td>

</tr>

<?php endforeach; ?>

</table>

</div>

</body>
</html>