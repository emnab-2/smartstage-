<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - SmartStage</title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet"
    >

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css"
        rel="stylesheet"
    >

  
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap"
        rel="stylesheet"
    >

    <style>
        :root {
            --primary: #7c3aed;
            --primary-dark: #5b21b6;
            --bg-dark: #050816;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            background:
                radial-gradient(circle at top, rgba(124,58,237,0.35), transparent 60%),
                radial-gradient(circle at bottom, rgba(56,189,248,0.25), transparent 55%),
                #020617;
            color: #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }

        .auth-shell {
            width: 100%;
            max-width: 960px;
            border-radius: 32px;
            background: radial-gradient(circle at top left, rgba(148,163,184,0.25), transparent 55%),
                        rgba(15,23,42,0.95);
            box-shadow:
                0 24px 80px rgba(15,23,42,0.85),
                0 0 0 1px rgba(148,163,184,0.2);
            overflow: hidden;
            display: grid;
            grid-template-columns: 1.1fr 0.9fr;
        }

        @media (max-width: 720px) {
            .auth-shell {
                grid-template-columns: 1fr;
                border-radius: 24px;
            }
            .auth-hero {
                display: none;
            }
        }

        .auth-main {
            padding: 40px 48px;
            background: linear-gradient(135deg, rgba(15,23,42,0.96), rgba(15,23,42,0.98));
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 32px;
        }

        .brand-badge {
            width: 36px;
            height: 36px;
            border-radius: 999px;
            background: radial-gradient(circle at 30% 0, #38bdf8, #0ea5e9 40%, #1d4ed8 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 18px;
            box-shadow: 0 0 0 1px rgba(15,23,42,0.5);
        }

        .brand-text {
            display: flex;
            flex-direction: column;
        }

        .brand-name {
            font-size: 18px;
            font-weight: 600;
            letter-spacing: 0.04em;
        }

        .brand-sub {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.14em;
            color: #9ca3af;
        }

        .auth-title {
            margin-bottom: 4px;
            font-size: 26px;
            font-weight: 600;
        }

        .auth-subtitle {
            font-size: 13px;
            color: #9ca3af;
            margin-bottom: 24px;
        }

        .auth-card {
            background: radial-gradient(circle at top, rgba(148,163,184,0.25), transparent 55%),
                        rgba(15,23,42,0.9);
            border-radius: 20px;
            padding: 22px 24px 24px;
            border: 1px solid rgba(148,163,184,0.25);
        }

        .auth-label {
            font-size: 13px;
            margin-bottom: 6px;
        }

        .form-control {
            background-color: rgba(15,23,42,0.8);
            border-radius: 999px;
            border: 1px solid rgba(148,163,184,0.45);
            color: #e5e7eb;
            font-size: 14px;
            padding: 10px 14px;
        }

        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 1px rgba(124,58,237,0.4);
            background-color: #020617;
            color: #f9fafb;
        }

        .form-control::placeholder {
            color: #6b7280;
        }

        .btn-primary-gradient {
            border-radius: 999px;
            border: none;
            width: 100%;
            font-weight: 500;
            font-size: 14px;
            padding: 10px 16px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow:
                0 10px 30px rgba(88,28,135,0.7),
                0 0 0 1px rgba(30,64,175,0.15);
        }

        .btn-primary-gradient:hover {
            background: linear-gradient(135deg, #8b5cf6, #4c1d95);
        }

        .auth-footer {
            margin-top: 16px;
            font-size: 12px;
            color: #9ca3af;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .auth-footer a {
            color: #e5e7eb;
            text-decoration: none;
            font-size: 12px;
        }

        .auth-footer a:hover {
            text-decoration: underline;
        }

        .auth-hero {
            position: relative;
            padding: 36px 34px;
            background:
                radial-gradient(circle at top right, rgba(96,165,250,0.35), transparent 55%),
                radial-gradient(circle at bottom left, rgba(251,191,36,0.4), transparent 65%),
                #020617;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .hero-heading {
            font-size: 22px;
            font-weight: 600;
            line-height: 1.3;
            margin-bottom: 12px;
        }

        .hero-copy {
            font-size: 13px;
            color: #e5e7eb;
            max-width: 260px;
        }

        .hero-pills {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-top: 18px;
        }

        .pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 10px;
            border-radius: 999px;
            background: rgba(15,23,42,0.75);
            border: 1px solid rgba(148,163,184,0.35);
            font-size: 12px;
            color: #e5e7eb;
            width: fit-content;
        }

        .pill-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 20px;
            height: 20px;
            border-radius: 999px;
            background: rgba(15,23,42,0.9);
        }

        .hero-metrics {
            display: flex;
            justify-content: flex-start;
            gap: 20px;
            margin-top: 28px;
        }

        .metric {
            font-size: 12px;
            color: #e5e7eb;
        }

        .metric strong {
            display: block;
            font-size: 18px;
        }

        .hero-footer {
            font-size: 11px;
            color: #9ca3af;
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="auth-shell">
        <section class="auth-main">
            <div class="brand">
                <div class="brand-badge">
                    <i class="bi bi-briefcase-fill"></i>
                </div>
                <div class="brand-text">
                    <span class="brand-name">SmartStage</span>
                    <span class="brand-sub">Internship Management Portal</span>
                </div>
            </div>

            <h1 class="auth-title">Connexion à votre espace</h1>
            <p class="auth-subtitle">
                Accédez à votre tableau de bord étudiant, entreprise ou responsable.
            </p>

            <div class="auth-card">
                <form method="POST" action="../controller/AuthController.php" class="mb-1">
                    <div class="mb-3">
                        <label class="auth-label" for="email">Adresse e-mail</label>
                        <input
                            id="email"
                            type="email"
                            name="email"
                            class="form-control"
                            placeholder="vous@example.com"
                            required
                        >
                    </div>

                    <div class="mb-3">
                        <label class="auth-label" for="password">Mot de passe</label>
                        <input
                            id="password"
                            type="password"
                            name="password"
                            class="form-control"
                            placeholder="Votre mot de passe"
                            required
                        >
                    </div>

                    <button type="submit" class="btn btn-primary-gradient">
                        Se connecter
                    </button>
                </form>

                <div class="auth-footer">
                    <span>
                        <small>Vous n'avez pas encore de compte ? <a href="register.php">S'inscrire</a></small>
                    </span>
                    <a href="index.php">
                        Retour à la page d'accueil
                    </a>
                </div>
            </div>
        </section>

        <aside class="auth-hero">
            <div>
                <p class="hero-heading">
                    Une plateforme unique pour gérer tous vos stages.
                </p>
                <p class="hero-copy">
                    Centralisez vos offres, candidatures et validations dans un environnement
                    simple et professionnel, pensé pour les écoles, entreprises et étudiants.
                </p>

                <div class="hero-pills">
                    <div class="pill">
                        <span class="pill-icon">
                            <i class="bi bi-mortarboard"></i>
                        </span>
                        Suivi des candidatures étudiant
                    </div>
                    <div class="pill">
                        <span class="pill-icon">
                            <i class="bi bi-building"></i>
                        </span>
                        Gestion des offres entreprise
                    </div>
                    <div class="pill">
                        <span class="pill-icon">
                            <i class="bi bi-shield-check"></i>
                        </span>
                        Validation par les responsables
                    </div>
                </div>

                <div class="hero-metrics">
                    <div class="metric">
                        <strong>10K+</strong>
                        étudiants accompagnés
                    </div>
                    <div class="metric">
                        <strong>500+</strong>
                        entreprises partenaires
                    </div>
                </div>
            </div>

            <div class="hero-footer">
                Accès sécurisé. Vos données restent confidentielles et hébergées de façon conforme.
            </div>
        </aside>
    </div>
</body>
</html>
