<?php 
require_once "../config/auth.php";
checkRole('responsable');

require_once "../model/OffreStage.php";

$offres = OffreStage::getAll();

$en_attente = 0;
$validee = 0;
$refusee = 0;

foreach ($offres as $o) {
    if ($o['statut'] == 'en_attente') $en_attente++;
    if ($o['statut'] == 'validee') $validee++;
    if ($o['statut'] == 'refusee') $refusee++;
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard Responsable</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { margin:0; font-family:'Poppins', sans-serif; }

.main {
    margin-left:250px;
    padding:40px;
    min-height:100vh;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color:white;
}

.container-dashboard {
    max-width:1100px;
    margin:auto;
}

.kpis {
    display:grid;
    grid-template-columns: repeat(3,1fr);
    gap:20px;
    margin-bottom:30px;
}

.kpi {
    background: rgba(255,255,255,0.05);
    padding:20px;
    border-radius:15px;
    text-align:center;
}

.cards {
    display:grid;
    grid-template-columns: repeat(2,1fr);
    gap:20px;
    margin-bottom:30px;
}

.card-box {
    background: rgba(255,255,255,0.05);
    padding:25px;
    border-radius:20px;
    text-align:center;
}

.btn-purple {
    background: linear-gradient(45deg,#8e2de2,#4a00e0);
    color:white;
}

.table {
    background: rgba(255,255,255,0.05);
    border-radius:15px;
}

.table th {
    background:#8e2de2;
}
</style>

</head>

<body>

<?php require_once "sidebar_responsable.php"; ?>

<div class="main">
<div class="container-dashboard">

<h1>Bienvenue <?= htmlspecialchars($_SESSION['user']['nom']) ?> 👨‍💼</h1>


<div class="kpis">

    <div class="kpi">
        <h2><?= $en_attente ?></h2>
        <p>En attente</p>
    </div>

    <div class="kpi">
        <h2><?= $validee ?></h2>
        <p>Validées</p>
    </div>

    <div class="kpi">
        <h2><?= $refusee ?></h2>
        <p>Refusées</p>
    </div>

</div>


<div class="cards">

    <div class="card-box">
        <h3>Gérer Offres</h3>
        <a href="offres_responsable.php" class="btn btn-purple">Accéder</a>
    </div>
    <div class="card-box">
    <h3>📊 Statistiques</h3>
      <p>Analyse de la plateforme</p>
    <button class="btn btn-secondary" disabled>
        Coming Soon
       </button>
    </div>

</div>

<h4>Offres en attente</h4>

<table class="table text-center">

<tr>
    <th>Entreprise</th>
    <th>Titre</th>
    <th>Date</th>
    <th>Action</th>
</tr>

<?php foreach ($offres as $o): ?>
<?php if ($o['statut'] == 'en_attente'): ?>

<tr>

<td><?= $o['nomEntreprise'] ?? '-' ?></td>

<td><?= $o['titre'] ?></td>

<td><?= $o['datePublication'] ?? '-' ?></td>

<td>
    <a href="../controller/OffreController.php?valider=<?= $o['idOffre'] ?>">✔</a>
    <a href="../controller/OffreController.php?refuser=<?= $o['idOffre'] ?>">❌</a>
</td>

</tr>

<?php endif; ?>
<?php endforeach; ?>

</table>

</div>
</div>

</body>
</html>