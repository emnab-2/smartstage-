<?php
require_once "../config/auth.php";
checkRole('etudiant');

require_once "../model/Candidature.php";
require_once "../model/OffreStage.php";

$user = $_SESSION['user'];


$candidatures = Candidature::getByEtudiant($user['idUtilisateur']);
$offres = OffreStage::getValidated();

$total = count($candidatures);

$en_attente = 0;
$acceptee = 0;

foreach ($candidatures as $c) {
    if ($c['statut'] == 'en_attente') $en_attente++;
    if ($c['statut'] == 'acceptee') $acceptee++;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Dashboard Étudiant</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { margin:0; font-family:'Poppins', sans-serif; }

.main {
    margin-left:250px;
    padding:40px;
    min-height:100vh;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color:white;
}

.container-dashboard {
    max-width:1100px;
    margin:auto;
}

.kpis {
    display:grid;
    grid-template-columns: repeat(4,1fr);
    gap:20px;
    margin-bottom:30px;
}

.kpi {
    background: rgba(255,255,255,0.05);
    padding:20px;
    border-radius:15px;
}

.offre-card {
    background: rgba(255,255,255,0.05);
    padding:20px;
    border-radius:15px;
    display:flex;
    justify-content:space-between;
    margin-bottom:15px;
}

.btn-purple {
    background: linear-gradient(45deg,#8e2de2,#4a00e0);
    color:white;
}
</style>

</head>

<body>

<?php require_once "sidebar_etudiant.php"; ?>

<div class="main">
<div class="container-dashboard">

<h1>Bienvenue <?= htmlspecialchars($user['nom']) ?> 👋</h1>


<div class="kpis">

    <div class="kpi">
        <h3><?= count($offres) ?></h3>
        <small>Offres</small>
    </div>

    <div class="kpi">
        <h3><?= $total ?></h3>
        <small>Candidatures</small>
    </div>

    <div class="kpi">
        <h3><?= $en_attente ?></h3>
        <small>En attente</small>
    </div>

</div>


<h4>Offres recommandées</h4>

<?php foreach ($offres as $o): ?>

<div class="offre-card">

    <div>
        <h5><?= $o['titre'] ?></h5>

        <small>
            <?= $o['nomEntreprise'] ?? 'Entreprise' ?>
        </small>
    </div>

    <div>
        <a href="../controller/CandidatureController.php?postuler=<?= $o['idOffre'] ?>"
           class="btn btn-purple btn-sm">
           Postuler
        </a>
    </div>

</div>

<?php endforeach; ?>

</div>
</div>

</body>
</html>