```php
<?php

session_start();

require_once "../model/OffreStage.php";



$search = trim($_GET['search'] ?? '');
$typeContrat = trim($_GET['typeContrat'] ?? '');



$offres = OffreStage::getValidated();



if (!empty($search)) {

    $offres = array_filter($offres, function($o) use ($search) {

        return
            stripos($o['titre'], $search) !== false ||

            stripos($o['competences'], $search) !== false ||

            stripos($o['nomEntreprise'], $search) !== false;
    });
}


if (!empty($typeContrat)) {

    $offres = array_filter($offres, function($o) use ($typeContrat) {

        return strtolower($o['typeContrat']) === strtolower($typeContrat);
    });
}



$types = [];

foreach ($offres as $o) {

    if (!empty($o['typeContrat'])) {

        $types[] = $o['typeContrat'];
    }
}

$types = array_unique($types);

?>

<!DOCTYPE html>
<html lang="fr">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Offres de Stage</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color:white;
}

.navbar{
    background: rgba(0,0,0,0.25);
    backdrop-filter: blur(12px);
}

.btn-purple{
    background: linear-gradient(45deg,#8e2de2,#4a00e0);
    border: none;
    color: white;
}

.btn-purple:hover{
    opacity:0.9;
    color:white;
}

.brand{
    font-size:22px;
    font-weight:bold;
    color:white;
    text-decoration:none;
}

.container-page{
    max-width:1300px;
    margin:auto;
    padding:30px;
}

.hero{
    text-align:center;
    margin-bottom:40px;
}

.hero h1{
    font-size:42px;
    font-weight:bold;
}

.hero p{
    color:#cbd5e1;
}

.layout{
    display:grid;
    grid-template-columns:280px 1fr;
    gap:25px;
}

.sidebar{
    background:rgba(255,255,255,0.06);
    border-radius:18px;
    padding:20px;
    height:fit-content;
}

.sidebar h5{
    margin-bottom:20px;
}

.form-control,
.form-select{
    background:rgba(255,255,255,0.08)!important;
    border:none!important;
    color:white!important;
}

.form-control::placeholder{
    color:#cbd5e1;
}

.btn-purple{
    background:linear-gradient(45deg,#8e2de2,#4a00e0);
    border:none;
    color:white;
    width:100%;
    margin-top:10px;
}

.offres-grid{
    display:grid;
    gap:20px;
}

.offre-card{
    background:rgba(255,255,255,0.06);
    border-radius:18px;
    padding:22px;
    transition:0.3s;
}

.offre-card:hover{
    transform:translateY(-4px);
    border:1px solid rgba(139,92,246,0.4);
}

.offre-title{
    font-size:22px;
    font-weight:bold;
}

.company{
    color:#cbd5e1;
    margin-bottom:12px;
}

.tags{
    display:flex;
    gap:10px;
    flex-wrap:wrap;
    margin:15px 0;
}

.tag{
    padding:6px 12px;
    border-radius:30px;
    font-size:13px;
}

.tag-type{
    background:#312e81;
}

.tag-skill{
    background:#0f766e;
}

.btn-postuler{
    background:linear-gradient(45deg,#8e2de2,#4a00e0);
    border:none;
    color:white;
    padding:10px 18px;
    border-radius:10px;
    text-decoration:none;
}

.empty{
    text-align:center;
    padding:60px;
    color:#cbd5e1;
}

@media(max-width:900px){

    .layout{
        grid-template-columns:1fr;
    }
}

</style>

</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark px-4 py-3">

    <div class="container-fluid">

        

        <a class="navbar-brand fw-bold fs-3"
           href="../index.php">

           SmartStage 

        </a>

        

        <div class="d-flex align-items-center gap-2">

            <a href="../index.php"
               class="btn btn-outline-light">

               🏠 Accueil

            </a>

            <a href="offres_public.php"
               class="btn btn-outline-light">

               💼 Offres

            </a>

            <?php if(isset($_SESSION['user'])): ?>

                <a href="dashboard_<?= strtolower($_SESSION['user']['role']) ?>.php"
                   class="btn btn-purple">

                   Dashboard

                </a>

            <?php else: ?>

                <a href="login.php"
                   class="btn btn-outline-light">

                   Login

                </a>

                <a href="register.php"
                   class="btn btn-light">

                   sign up

                </a>

            <?php endif; ?>

        </div>

    </div>

</nav>

<div class="container-page">

<div class="hero">

<h1>Explorez les offres de stage 💼</h1>

<p>
Découvrez toutes les opportunités validées publiées par les entreprises.
</p>

</div>

<div class="layout">

<!-- SIDEBAR -->

<div class="sidebar">

<h5>Filtres 🔎</h5>

<form method="GET">

<div class="mb-3">

<input type="text"
       name="search"
       class="form-control"
       placeholder="Recherche..."
       value="<?= htmlspecialchars($search) ?>">

</div>

<div class="mb-3">

<select name="typeContrat" class="form-select">

<option value="">Tous les types</option>

<?php foreach($types as $t): ?>

<option value="<?= $t ?>"
<?= $typeContrat === $t ? 'selected' : '' ?>>

<?= $t ?>

</option>

<?php endforeach; ?>

</select>

</div>

<button class="btn btn-purple">

Appliquer

</button>

</form>

</div>


<div class="offres-grid">

<?php if(empty($offres)): ?>

<div class="empty">

<h3>Aucune offre trouvée 😢</h3>

<p>Essayez un autre filtre.</p>

</div>

<?php else: ?>

<?php foreach($offres as $o): ?>

<div class="offre-card">

<div class="offre-title">

<?= htmlspecialchars($o['titre']) ?>

</div>

<div class="company">

🏢 <?= htmlspecialchars($o['nomEntreprise']) ?>

</div>

<p>

<?= htmlspecialchars($o['description']) ?>

</p>

<div class="tags">

<span class="tag tag-type">

<?= htmlspecialchars($o['typeContrat']) ?>

</span>

<?php

$competences = explode(',', $o['competences']);

foreach($competences as $c):

?>

<span class="tag tag-skill">

<?= htmlspecialchars(trim($c)) ?>

</span>

<?php endforeach; ?>

</div>

<div class="d-flex justify-content-between align-items-center">

<small>

📅 <?= date('d/m/Y', strtotime($o['datePublication'])) ?>

</small>

<?php if(
    isset($_SESSION['user']) &&
    $_SESSION['user']['role'] === 'etudiant'
): ?>

<a href="../controller/CandidatureController.php?postuler=<?= $o['idOffre'] ?>"
   class="btn-postuler">

Postuler 🚀

</a>

<?php else: ?>

<a href="login.php" class="btn-postuler">

Se connecter

</a>

<?php endif; ?>

</div>

</div>

<?php endforeach; ?>

<?php endif; ?>

</div>

</div>

</div>

</body>

</html>

