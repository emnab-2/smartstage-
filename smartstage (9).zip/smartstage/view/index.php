<!DOCTYPE html>

<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SmartStage </title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">

<style>
body {
    margin:0;
    font-family: 'Poppins', sans-serif;
    background-color: #0b1024;
    color:white;
    overflow-x:hidden;
    position: relative;
}

body::before,
body::after {
    content: "";
    position: fixed;
    border-radius: 999px;
    filter: blur(70px);
    z-index: -1;
    pointer-events: none;
}

body::before {
    inset: 0;
    width: auto;
    height: auto;
    border-radius: 0;
    filter: none;
    background-image:
        linear-gradient(140deg, rgba(8,12,35,0.86), rgba(24,16,68,0.72)),
        linear-gradient(to bottom, rgba(10,14,40,0.55), rgba(10,14,40,0.75)),
        url('https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=2000&q=80');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    z-index: -2;
}

body::after {
    width: 460px;
    height: 460px;
    background: rgba(129,140,248,0.14);
    right: -150px;
    top: 140px;
    z-index: -1;
}

.navbar {
    background: rgba(0,0,0,0.4);
    backdrop-filter: blur(12px);
}

.hero {
    min-height: 100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    text-align:center;
    position: relative;
    padding: 0 18px;
}

.hero h1 {
    font-size:60px;
    font-weight:700;
    background: linear-gradient(90deg,#a855f7,#6366f1);
    -webkit-background-clip: text;
    color: transparent;
}

.hero p {
    opacity:0.8;
}

.hero-subcards {
    margin-top: 28px;
    display: flex;
    gap: 12px;
    justify-content: center;
    flex-wrap: wrap;
}

.hero-subcard {
    background: rgba(255,255,255,0.1);
    border: 1px solid rgba(255,255,255,0.2);
    backdrop-filter: blur(10px);
    border-radius: 999px;
    padding: 8px 14px;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.hero-icon-bubble {
    position: absolute;
    width: 72px;
    height: 72px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255,255,255,0.08);
    border: 1px solid rgba(255,255,255,0.2);
    backdrop-filter: blur(8px);
    color: #c4b5fd;
    font-size: 28px;
    box-shadow: 0 10px 28px rgba(15,23,42,0.45);
}

.hero-icon-1 { left: 10%; top: 26%; }
.hero-icon-2 { right: 12%; top: 28%; }
.hero-icon-3 { right: 18%; bottom: 18%; }

.btn-purple {
    background: linear-gradient(45deg,#8e2de2,#4a00e0);
    border:none;
    color:white;
    box-shadow: 0 0 15px rgba(128,0,255,0.6);
}

.card-ai {
    background: rgba(255,255,255,0.05);
    border-radius:20px;
    padding:25px;
    backdrop-filter: blur(20px);
    transition:0.3s;
}

.card-ai:hover {
    transform: translateY(-10px);
    box-shadow:0 0 25px rgba(128,0,255,0.7);
}

.section {
    padding:100px 0;
}

.fade-up {
    opacity:0;
    transform:translateY(30px);
    transition:0.8s;
}

.fade-up.show {
    opacity:1;
    transform:translateY(0);
}

@media (max-width: 900px) {
    .hero h1 {
        font-size: 44px;
    }

    .hero-icon-bubble {
        display: none;
    }
}
</style>

</head>

<body>


<nav class="navbar navbar-dark px-4 py-3">

    <span class="navbar-brand fw-bold">
        SmartStage 
    </span>

    <div class="d-flex align-items-center">

        <a href="offres_public.php"
           class="btn btn-outline-light me-2">

           💼 Offres

        </a>

        <a href="login.php"
           class="btn btn-outline-light me-2">

           Login

        </a>

        <a href="register.php"
           class="btn btn-purple">

           Sign Up

        </a>

    </div>

</nav>

<section class="hero">
    <div class="hero-icon-bubble hero-icon-1">
        <i class="bi bi-briefcase-fill"></i>
    </div>
    <div class="hero-icon-bubble hero-icon-2">
        <i class="bi bi-mortarboard-fill"></i>
    </div>
    <div class="hero-icon-bubble hero-icon-3">
        <i class="bi bi-file-earmark-check-fill"></i>
    </div>
    <div>
        <h1 class="mb-3">Launch Your Career with AI 💜</h1>
        <p>Find internships, apply instantly, and track your progress</p>
    <a href="register.php" class="btn btn-purple mt-4 px-5 py-2">
        Get Started
    </a>
    <div class="hero-subcards">
        <span class="hero-subcard"><i class="bi bi-building"></i> 500+ Companies</span>
        <span class="hero-subcard"><i class="bi bi-people-fill"></i> 10K+ Students</span>
        <span class="hero-subcard"><i class="bi bi-lightning-charge-fill"></i> Fast Apply</span>
    </div>
</div>

</section>


<section class="section container text-center">
    <h2 class="mb-5">✨ Powerful Features</h2>
<div class="row">

    <div class="col-md-4 mb-4 fade-up">
        <div class="card-ai">
            <i class="bi bi-search display-5"></i>
            <h5 class="mt-3">Smart Matching</h5>
            <p>AI suggests the best offers for you</p>
        </div>
    </div>

    <div class="col-md-4 mb-4 fade-up">
        <div class="card-ai">
            <i class="bi bi-lightning-charge display-5"></i>
            <h5 class="mt-3">Fast Apply</h5>
            <p>Apply to internships in one click</p>
        </div>
    </div>

    <div class="col-md-4 mb-4 fade-up">
        <div class="card-ai">
            <i class="bi bi-graph-up display-5"></i>
            <h5 class="mt-3">Track Progress</h5>
            <p>Follow your applications in real time</p>
        </div>
    </div>

</div>

</section>

<section class="section text-center">
    <div class="container">
        <h2 class="mb-5">📊 Platform Stats</h2>
    <div class="row">
        <div class="col-md-4 fade-up">
            <h1>10K+</h1>
            <p>Students</p>
        </div>
        <div class="col-md-4 fade-up">
            <h1>500+</h1>
            <p>Companies</p>
        </div>
        <div class="col-md-4 fade-up">
            <h1>95%</h1>
            <p>Success Rate</p>
        </div>
    </div>
</div>

</section>


<section class="section text-center">
    <h2>Ready to start?</h2>
    <a href="register.php" class="btn btn-purple mt-3 px-5">Join Now</a>
</section>


<footer class="text-center py-4">
    © 2026 SmartStage 💜
</footer>

<script>
const elements = document.querySelectorAll('.fade-up');

window.addEventListener('scroll', () => {
    elements.forEach(el => {
        const position = el.getBoundingClientRect().top;
        if (position < window.innerHeight - 50) {
            el.classList.add('show');
        }
    });
});
</script>

</body>
</html>
