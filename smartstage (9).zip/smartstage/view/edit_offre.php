<?php
require_once "../config/auth.php";
checkRole('entreprise');
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Modifier Offre</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body { margin: 0; font-family: 'Poppins', sans-serif; }

.main {
    margin-left: 250px;
    padding: 34px 40px;
    min-height: 100vh;
    background: linear-gradient(135deg,#0f0c29,#302b63,#24243e);
    color: white;
}

.form-card {
    max-width: 760px;
    background: rgba(255,255,255,0.08);
    border-radius: 18px;
    padding: 22px;
}

.form-control {
    background: rgba(15,23,42,0.8);
    color: white;
}
</style>

</head>

<body>

<?php require_once "sidebar_entreprise.php"; ?>

<main class="main">

<h2>Modifier Offre ✏️</h2>

<div class="form-card">

<form method="POST" action="../controller/OffreController.php">

<input type="hidden" name="id" value="<?= $offre['idOffre'] ?>">

<div class="mb-3">
<label>Titre</label>
<input type="text" name="titre" class="form-control"
       value="<?= htmlspecialchars($offre['titre']) ?>" required>
</div>

<div class="mb-3">
<label>Description</label>
<textarea name="description" class="form-control" rows="4">
<?= htmlspecialchars($offre['description']) ?>
</textarea>
</div>

<div class="mb-3">
<label>Compétences</label>
<input type="text" name="competences" class="form-control"
       value="<?= htmlspecialchars($offre['competences']) ?>">
</div>

<div class="mb-3">
<label>Type contrat</label>
<input type="text" name="typeContrat" class="form-control"
       value="<?= htmlspecialchars($offre['typeContrat']) ?>">
</div>

<button type="submit" name="update" class="btn btn-primary">
💾 Enregistrer
</button>

</form>

</div>

</main>

</body>
</html>