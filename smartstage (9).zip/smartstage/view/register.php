<?php
session_start();
$error = $_SESSION['register_error'] ?? null;
$old = $_SESSION['register_old'] ?? [];
unset($_SESSION['register_error'], $_SESSION['register_old']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - SmartStage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            background:
                radial-gradient(circle at top, rgba(124,58,237,0.35), transparent 60%),
                radial-gradient(circle at bottom, rgba(56,189,248,0.25), transparent 55%),
                #020617;
            color: #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .auth-shell {
            width: 100%;
            max-width: 980px;
            border-radius: 28px;
            background: rgba(15,23,42,0.94);
            box-shadow: 0 24px 80px rgba(15,23,42,0.85);
            overflow: hidden;
            display: grid;
            grid-template-columns: 1fr 1fr;
        }
        .left {
            padding: 34px;
            background: radial-gradient(circle at top left, rgba(148,163,184,0.18), transparent 60%), #0f172a;
        }
        .right {
            padding: 34px;
            background: radial-gradient(circle at bottom right, rgba(96,165,250,0.2), transparent 65%), #020617;
        }
        .brand {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 24px;
        }
        .feature {
            border: 1px solid rgba(148,163,184,0.3);
            background: rgba(15,23,42,0.6);
            border-radius: 14px;
            padding: 12px;
            margin-bottom: 10px;
            font-size: 13px;
        }
        .form-control, .form-select {
            border-radius: 12px;
            background: rgba(15,23,42,0.8);
            border: 1px solid rgba(148,163,184,0.4);
            color: #e5e7eb;
        }
        .form-control:focus, .form-select:focus {
            border-color: #7c3aed;
            box-shadow: 0 0 0 1px rgba(124,58,237,0.4);
            background: #020617;
            color: #f8fafc;
        }
        .btn-primary-gradient {
            border: none;
            border-radius: 999px;
            width: 100%;
            color: white;
            font-weight: 500;
            padding: 10px 16px;
            background: linear-gradient(135deg, #7c3aed, #5b21b6);
        }
        .btn-primary-gradient:hover {
            background: linear-gradient(135deg, #8b5cf6, #4c1d95);
        }
        .hint {
            color: #9ca3af;
            font-size: 12px;
        }
        @media (max-width: 900px) {
            .auth-shell {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="auth-shell">
        <section class="left">
            <div class="brand">
                <i class="bi bi-briefcase-fill"></i> SmartStage
            </div>
            <h3 class="mb-2">Créer votre compte</h3>
            <p class="text-secondary mb-4">Rejoignez la plateforme pour publier ou postuler à des stages.</p>

            <div class="feature"><i class="bi bi-check2-circle me-2"></i>Inscription rapide étudiant/entreprise</div>
            <div class="feature"><i class="bi bi-check2-circle me-2"></i>Suivi des offres et candidatures</div>
            <div class="feature"><i class="bi bi-check2-circle me-2"></i>Tableau de bord adapté à votre rôle</div>
        </section>

        <section class="right">
            <h4 class="mb-3">Inscription</h4>

            <?php if ($error): ?>
                <div class="alert alert-danger py-2">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="../controller/RegisterController.php">
                <div class="mb-3">
                    <label class="form-label">Nom complet</label>
                    <input type="text" name="nom" class="form-control" required value="<?= htmlspecialchars($old['nom'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" required value="<?= htmlspecialchars($old['email'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Rôle</label>
                    <select name="role" id="roleSelect" class="form-select" required>
                        <option value="">Sélectionner un rôle</option>
                        <option value="etudiant" <?= (($old['role'] ?? '') === 'etudiant') ? 'selected' : '' ?>>Étudiant</option>
                        <option value="entreprise" <?= (($old['role'] ?? '') === 'entreprise') ? 'selected' : '' ?>>Entreprise</option>
                    </select>
                </div>

                <div class="mb-3" id="companyField" style="display:none;">
                    <label class="form-label">Nom de l'entreprise</label>
                    <input type="text" name="nom_entreprise" class="form-control" value="<?= htmlspecialchars($old['nom_entreprise'] ?? '') ?>">
                    <div class="hint mt-1">Requis seulement pour les comptes entreprise.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Mot de passe</label>
                    <input type="password" name="password" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Confirmer le mot de passe</label>
                    <input type="password" name="confirm_password" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary-gradient">Créer le compte</button>
            </form>

            <p class="mt-3 mb-0 hint">
                Déjà inscrit ? <a href="login.php" class="text-decoration-none">Se connecter</a>
            </p>
        </section>
    </div>

    <script>
        const roleSelect = document.getElementById('roleSelect');
        const companyField = document.getElementById('companyField');

        function toggleCompanyField() {
            companyField.style.display = roleSelect.value === 'entreprise' ? 'block' : 'none';
        }

        roleSelect.addEventListener('change', toggleCompanyField);
        toggleCompanyField();
    </script>
</body>
</html>
