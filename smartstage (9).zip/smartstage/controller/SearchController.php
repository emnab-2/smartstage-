<?php
require_once "../model/OffreStage.php";

header('Content-Type: application/json; charset=utf-8');


$q = isset($_GET['q']) ? trim($_GET['q']) : '';

$data = OffreStage::search($q);

echo json_encode($data, JSON_UNESCAPED_UNICODE);

exit;
?>