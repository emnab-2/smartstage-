<?php

require_once "../config/auth.php";
require_once "../model/Candidature.php";


if (isset($_GET['postuler'])) {

    checkRole('etudiant');

    $idOffre = intval($_GET['postuler']);
    $idEtudiant = intval($_SESSION['user']['idUtilisateur']);

    Candidature::postuler($idOffre, $idEtudiant);

    header("Location: ../view/offres_etudiant.php");
    exit();
}


if (isset($_GET['accepter'])) {

    checkRole('entreprise');

    $idCandidature = intval($_GET['accepter']);

    Candidature::accepter($idCandidature);

    header("Location: ../view/candidatures.php");
    exit();
}


if (isset($_GET['refuser'])) {

    checkRole('entreprise');

    $idCandidature = intval($_GET['refuser']);

    Candidature::refuser($idCandidature);

    header("Location: ../view/candidatures.php");
    exit();
}
?>