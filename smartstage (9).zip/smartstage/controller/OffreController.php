<?php

session_start();

require_once "../model/OffreStage.php";


if (isset($_POST['add'])) {

    $user = $_SESSION['user'];

    OffreStage::add(

        trim($_POST['titre']),
        trim($_POST['description']),
        trim($_POST['competences']),
        trim($_POST['typeContrat']),
        intval($user['idUtilisateur'])
    );

    header("Location: ../view/offres_entreprise.php");
    exit();
}

if (isset($_POST['update'])) {

    OffreStage::update(

        intval($_POST['id']),
        trim($_POST['titre']),
        trim($_POST['description']),
        trim($_POST['competences']),
        trim($_POST['typeContrat'])
    );

    header("Location: ../view/offres_entreprise.php");
    exit();
}

if (isset($_GET['delete'])) {

    OffreStage::delete(
        intval($_GET['delete'])
    );

    header("Location: ../view/offres_entreprise.php");
    exit();
}


if (isset($_GET['valider'])) {

    $user = $_SESSION['user'];

    OffreStage::valider(

        intval($_GET['valider']),
        intval($user['idUtilisateur'])
    );

    header("Location: ../view/offres_responsable.php");
    exit();
}


if (isset($_GET['refuser'])) {

    $user = $_SESSION['user'];

    OffreStage::refuser(

        intval($_GET['refuser']),
        intval($user['idUtilisateur'])
    );

    header("Location: ../view/offres_responsable.php");
    exit();
}


if (isset($_GET['search'])) {

    $keyword = trim($_GET['search']);

    $offres = OffreStage::search($keyword);

    require_once "../view/offres.php";
    exit();
}


if (isset($_GET['edit'])) {

    $id = intval($_GET['edit']);

    $offre = OffreStage::getById($id);

    require_once "../view/edit_offre.php";
    exit();
}
?>