<?php

session_start();

require_once "../model/Utilisateur.php";


if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    header("Location: ../view/register.php");
    exit();
}


$nom = trim($_POST['nom'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');
$confirm = trim($_POST['confirm_password'] ?? '');
$role = trim($_POST['role'] ?? '');
$nomEntreprise = trim($_POST['nom_entreprise'] ?? '');



if (
    $nom === '' ||
    $email === '' ||
    $password === '' ||
    $confirm === '' ||
    $role === ''
) {

    $_SESSION['register_error'] =
        "Veuillez remplir tous les champs obligatoires.";

    $_SESSION['register_old'] = $_POST;

    header("Location: ../view/register.php");
    exit();
}


if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    $_SESSION['register_error'] =
        "Adresse email invalide.";

    $_SESSION['register_old'] = $_POST;

    header("Location: ../view/register.php");
    exit();
}



if ($password !== $confirm) {

    $_SESSION['register_error'] =
        "Les mots de passe ne correspondent pas.";

    $_SESSION['register_old'] = $_POST;

    header("Location: ../view/register.php");
    exit();
}


if (strlen($password) < 4) {

    $_SESSION['register_error'] =
        "Le mot de passe doit contenir au moins 4 caractères.";

    $_SESSION['register_old'] = $_POST;

    header("Location: ../view/register.php");
    exit();
}



list($ok, $result) = Utilisateur::register(

    $nom,
    $email,
    $password,
    $role,
    $nomEntreprise
);



if (!$ok) {

    $_SESSION['register_error'] = $result;
    $_SESSION['register_old'] = $_POST;

    header("Location: ../view/register.php");
    exit();
}


$_SESSION['user'] = $result;



if ($result['role'] === 'entreprise') {

    header("Location: ../view/dashboard_entreprise.php");
    exit();
}

if ($result['role'] === 'responsable') {

    header("Location: ../view/dashboard_responsable.php");
    exit();
}


header("Location: ../view/dashboard_etudiant.php");
exit();

?>