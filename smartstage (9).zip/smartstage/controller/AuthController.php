<?php

session_start();

require_once "../model/Utilisateur.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {

        die("Veuillez remplir tous les champs.");
    }

    $user = Utilisateur::login($email, $password);

    if ($user) {

        $_SESSION['user'] = $user;

        $role = strtolower($user['role']);

        switch ($role) {

            case 'etudiant':
                header("Location: ../view/dashboard_etudiant.php");
                break;

            case 'entreprise':
                header("Location: ../view/dashboard_entreprise.php");
                break;

            case 'responsable':
                header("Location: ../view/dashboard_responsable.php");
                break;

            default:
                header("Location: ../view/login.php");
        }

        exit();

    } else {

        echo "Email ou mot de passe incorrect ❌";
    }
}


if (isset($_GET['logout'])) {

    session_unset();
    session_destroy();

    header("Location: ../view/login.php");
    exit();
}
?>