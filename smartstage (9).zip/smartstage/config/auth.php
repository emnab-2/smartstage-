<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


function checkAuth() {

    if (!isset($_SESSION['user'])) {

        header("Location: ../view/login.php");
        exit();
    }
}


function checkRole($role) {

    checkAuth();

    $currentRole = strtolower(trim($_SESSION['user']['role']));
    $requiredRole = strtolower(trim($role));

    if ($currentRole !== $requiredRole) {

        die("⛔ Access denied");
    }
}

function getUser() {

    return $_SESSION['user'] ?? null;
}
?>