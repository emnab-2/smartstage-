<?php

function getConnection() {

    $host = "sql202.byethost6.com";
    $dbname = "b6_41860985_smartstage";
    $user = "b6_41860985";
    $password = "Fortnitefortnite6";

    try {

        $pdo = new PDO(
            "mysql:host=$host;dbname=$dbname;charset=utf8",
            $user,
            $password
        );

        $pdo->setAttribute(
            PDO::ATTR_ERRMODE,
            PDO::ERRMODE_EXCEPTION
        );

        return $pdo;

    } catch(PDOException $e) {

        die("Erreur connexion : " . $e->getMessage());
    }
}
?>