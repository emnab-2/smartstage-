<?php
require "config/database.php";
header("Location: view/index.php");
exit();
?>